package com.example.orderingsystem;
import java.io.Serializable;

public class LoginDetail implements Serializable {
    public String email;
    public String name;
    public String uid;
    public String status;
    public String restaurantId;

    public LoginDetail() {

    }

    public LoginDetail(String email, String name, String uid, String status, String restaurantId){
        this.email = email;
        this.name = name;
        this.uid = uid;
        this.status = status;
        this.restaurantId = restaurantId;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getUid() {
        return uid;
    }

    public String getStatus() {
        return status;
    }

    public String getRestaurantId() {
        return restaurantId;
    }
}
