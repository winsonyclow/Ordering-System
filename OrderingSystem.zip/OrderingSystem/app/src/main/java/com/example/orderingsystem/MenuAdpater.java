package com.example.orderingsystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MenuAdpater extends RecyclerView.Adapter<MenuAdpater.MenuViewHolder> {
    private ArrayList<MenuItem> mMenuList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void OnItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public static class MenuViewHolder extends RecyclerView.ViewHolder{
        public ImageView iv_menuImage;
        public TextView tv_menuName;
        public TextView tv_menuPrice;

        public MenuViewHolder(View itemView, final OnItemClickListener listener){
            super(itemView);
            iv_menuImage = itemView.findViewById(R.id.iv_menuImage);
            tv_menuName = itemView.findViewById(R.id.tv_menuName);
            tv_menuPrice = itemView.findViewById(R.id.tv_menuPrice);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.OnItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public MenuAdpater(ArrayList<MenuItem> menuList){
        mMenuList = menuList;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.member_menu_item, parent, false);
        MenuViewHolder mvh = new MenuViewHolder(v, mListener);

        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        MenuItem currentItem = mMenuList.get(position);

        holder.iv_menuImage.setImageResource(currentItem.getImageResource());
        holder.tv_menuName.setText(currentItem.getName());
        holder.tv_menuPrice.setText(String.format("%.2f", Double.parseDouble(currentItem.getPrice())));
    }


    @Override
    public int getItemCount() {
        return mMenuList.size();
    }
}
