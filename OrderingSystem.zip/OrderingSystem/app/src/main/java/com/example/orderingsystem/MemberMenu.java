package com.example.orderingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MemberMenu extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private MenuAdpater mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_menu);

        Intent i = getIntent();
        final RestaurantSeat rs = (RestaurantSeat)  i.getSerializableExtra("Restaurant Seat");

        final String restaurantId = rs.getRestaurantId();
        final ArrayList<MenuItem> menu = new ArrayList<>();
        final int[] resourceId = new int[1];

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("menu");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    if(ds.child("restaurantId").getValue().toString().equals(restaurantId)){
                        resourceId[0] = getResources().getIdentifier(ds.child("menuId").getValue().toString(), "drawable", "com.example.orderingsystem");
                        menu.add(new MenuItem(ds.child("menuId").getValue().toString(), resourceId[0], ds.child("name").getValue().toString(),
                                ds.child("price").getValue().toString()));
                    }
                }
                mRecyclerView = findViewById(R.id.rv_member_menu);
                mRecyclerView.setHasFixedSize(true);
                mLayoutManager = new LinearLayoutManager(getBaseContext());
                mAdapter = new MenuAdpater(menu);

                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);

                mAdapter.setOnItemClickListener(new MenuAdpater.OnItemClickListener() {
                    @Override
                    public void OnItemClick(int position) {
                        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                        String restaurant = rs.getRestaurantId();
                        String menuId = menu.get(position).getMenuId();
                        String uid = currentFirebaseUser.getUid();
                        String table = rs.getSeatNo();
                        String price = menu.get(position).getPrice();
                        int imageResource = menu.get(position).getImageResource();
                        String name = menu.get(position).getName();

                        Order order = new Order(restaurant, menuId, uid, table, price, imageResource, name);
                        Intent i = new Intent(MemberMenu.this, MemberOrder.class);
                        i.putExtra("Order", order);
                        startActivity(i);
                    }
                });

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }
}
