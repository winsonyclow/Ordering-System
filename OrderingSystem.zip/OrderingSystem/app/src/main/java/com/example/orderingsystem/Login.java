package com.example.orderingsystem;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class Login extends AppCompatActivity {
    EditText et_email, et_password;
    Button btn_login;
    TextView tv_register;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PackageManager.PERMISSION_GRANTED);

        mFirebaseAuth= FirebaseAuth.getInstance();
        et_email = findViewById(R.id.et_loginEmail);
        et_password = findViewById(R.id.et_loginPassword);
        btn_login = findViewById(R.id.btn_login);
        tv_register = findViewById(R.id.tv_register);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if(mFirebaseUser != null){
                    final LoginDetail[] d = new LoginDetail[1];
                    FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                    final String uid = currentFirebaseUser.getUid();
                    final FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference ref = database.getReference("user");
                    ref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for(DataSnapshot ds : dataSnapshot.getChildren()){
                                if(ds.child("uid").getValue().toString().equals(uid)){
                                    d[0] = new LoginDetail(ds.child("email").getValue().toString(), ds.child("name").getValue().toString(),
                                            ds.child("uid").getValue().toString(), ds.child("status").getValue().toString(), ds.child("restaurantId").getValue().toString());
                                }
                            }
                            LoginDetail ld = d[0];
                            switch(ld.getStatus()){
                                case "member":
                                    Intent i = new Intent(Login.this, MemberMain.class);
                                    i.putExtra("Login Detail", ld);
                                    finish();
                                    startActivity(i);
                                    break;
                                case "kitchen":
                                    Intent j = new Intent(Login.this, KitchenMain.class);
                                    j.putExtra("Login Detail", ld);
                                    finish();
                                    startActivity(j);
                                    break;
                                case "cashier":
                                    Intent k = new Intent(Login.this, CashierMain.class);
                                    k.putExtra("Login Detail", ld);
                                    finish();
                                    startActivity(k);
                                    break;
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            System.out.println("The read failed: " + databaseError.getCode());
                        }


                    });
                }
                else{
                    Toast.makeText(Login.this, "Please login", Toast.LENGTH_SHORT).show();
                }
            }
        };

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = et_email.getText().toString();
                String password = et_password.getText().toString();
                if(email.isEmpty() && password.isEmpty()){
                    Toast.makeText(Login.this, "Fields are empty!",Toast.LENGTH_SHORT).show();
                }
                else if(email.isEmpty()){
                    et_email.setError("Please enter email");
                    et_email.requestFocus();
                }
                else if(password.isEmpty()){
                    et_password.setError("Please enter password");
                    et_password.requestFocus();
                }
                else if(!(email.isEmpty() && password.isEmpty())){
                    mFirebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(Login.this, "Incorrect e-mail or password", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(Login.this, "Login complete", Toast.LENGTH_SHORT).show();
                                final LoginDetail[] d = new LoginDetail[1];
                                FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                                final String uid = currentFirebaseUser.getUid();

                                final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference ref = database.getReference("user");
                                ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        for(DataSnapshot ds : dataSnapshot.getChildren()){
                                            if(ds.child("uid").getValue().toString().equals(uid)){
                                                d[0] = new LoginDetail(ds.child("email").getValue().toString(), ds.child("name").getValue().toString(),
                                                        ds.child("uid").getValue().toString(), ds.child("status").getValue().toString(), ds.child("restaurantId").getValue().toString());
                                            }
                                        }
                                        LoginDetail ld = d[0];
                                        switch(ld.getStatus()){
                                            case "member":
                                                Intent i = new Intent(Login.this, MemberMain.class);
                                                i.putExtra("Login Detail", ld);
                                                finish();
                                                startActivity(i);
                                                break;
                                            case "kitchen":
                                                Intent j = new Intent(Login.this, KitchenMain.class);
                                                j.putExtra("Login Detail", ld);
                                                finish();
                                                startActivity(j);
                                                break;
                                            case "cashier":
                                                Intent k = new Intent(Login.this, CashierMain.class);
                                                k.putExtra("Login Detail", ld);
                                                finish();
                                                startActivity(k);
                                                break;
                                        }
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {
                                        System.out.println("The read failed: " + databaseError.getCode());
                                    }
                                });
                            }
                        }
                    });
                }
                else{
                    Toast.makeText(Login.this, "Error Occurred!",Toast.LENGTH_SHORT).show();
                }
            }
        });

        tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(Login.this, Register.class));
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }
}
