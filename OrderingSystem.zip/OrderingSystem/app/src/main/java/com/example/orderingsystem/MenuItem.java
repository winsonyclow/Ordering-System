package com.example.orderingsystem;

public class MenuItem {
    public String menuId;
    public int mImageResource;
    public String name;
    public String price;

    public MenuItem(String menuId, int mImageResource, String name, String price){
        this.menuId = menuId;
        this.mImageResource = mImageResource;
        this.name = name;
        this.price = price;
    }

    public String getMenuId() {
        return menuId;
    }

    public int getImageResource(){
        return mImageResource;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
}
