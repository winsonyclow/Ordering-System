package com.example.orderingsystem;

import java.io.Serializable;

public class Order implements Serializable {
    public String restaurantId;
    public String menuId;
    public String uid;
    public String tableNo;
    public String price;
    public int imageResource;
    public String name;

    public String orderId;
    public String quantity;
    public String progress;


    public Order(String restaurantId, String menuId, String uid, String tableNo, String price, int imageResource, String name){
        this.restaurantId = restaurantId;
        this.menuId = menuId;
        this.uid = uid;
        this.tableNo = tableNo;
        this.price = price;
        this.imageResource = imageResource;
        this.name = name;
    }

    public Order(String restaurantId, String menuId, String uid, String tableNo, String price, String name, String quantity, String progress, String orderId){
        this.restaurantId = restaurantId;
        this.menuId = menuId;
        this.uid = uid;
        this.tableNo = tableNo;
        this.price = price;
        this.name = name;
        this.quantity = quantity;
        this.progress = progress;
        this.orderId = orderId;
    }

    public Order(String name, String tableNo, String quantity, String orderId){
        this.name = name;
        this.tableNo = tableNo;
        this.quantity = quantity;
        this.orderId = orderId;
    }

    public Order(String name, String quantity, String price, String orderId, String uid){
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.orderId = orderId;
        this.uid = uid;
    }

    public String getRestaurantId() {
        return restaurantId;
    }

    public String getMenuId() {
        return menuId;
    }

    public String getUid() {
        return uid;
    }

    public String getTableNo() {
        return tableNo;
    }

    public String getPrice() {
        return price;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getProgress() {
        return progress;
    }

    public String getOrderId() {
        return orderId;
    }
}
