package com.example.orderingsystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {
    private ArrayList<Order> mOrders;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void OnCompleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder{
        public TextView tv_orderName, tv_orderQuantity, tv_orderTableNo;
        public ImageView iv_orderComplete;

        public OrderViewHolder(View itemView, final OnItemClickListener listener){
            super(itemView);
            tv_orderName = itemView.findViewById(R.id.tv_orderName);
            tv_orderQuantity = itemView.findViewById(R.id.tv_orderQuantity);
            tv_orderTableNo = itemView.findViewById(R.id.tv_orderTableNo);
            iv_orderComplete = itemView.findViewById(R.id.iv_orderComplete);

            iv_orderComplete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.OnCompleteClick(position);
                        }
                    }
                }
            });
        }
    }

    public OrderAdapter(ArrayList<Order> orders){
        mOrders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.kitchen_order_item, parent, false);
        OrderViewHolder mvh = new OrderViewHolder(v, mListener);

        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order currentItem = mOrders.get(position);

        holder.tv_orderName.setText(currentItem.getName());
        holder.tv_orderQuantity.setText(currentItem.getQuantity());
        holder.tv_orderTableNo.setText(currentItem.getTableNo());
    }


    @Override
    public int getItemCount() {
        return mOrders.size();
    }
}
