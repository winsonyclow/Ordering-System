package com.example.orderingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CashierFagmentPayment extends Fragment implements View.OnClickListener {
    ImageView ib_scanPayment;
    private String restaurantId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cashier_fragment_payment, container, false);

        ib_scanPayment = view.findViewById(R.id.ib_scanPayment);
        ib_scanPayment.setOnClickListener(this);

        Bundle b = getArguments();
        restaurantId = b.getString("Restaurant ID");

        return view;
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getActivity(), CashierScanner.class);
        i.putExtra("Restaurant ID", restaurantId);
        startActivity(i);
    }
}
