package com.example.orderingsystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PaymentAdpater extends RecyclerView.Adapter<PaymentAdpater.PaymentViewHolder> {
    private ArrayList<Order> mOrders;

    public static class PaymentViewHolder extends RecyclerView.ViewHolder{
        public TextView tv_paymentName, tv_paymentQuantity, tv_paymentPrice;

        public PaymentViewHolder(View itemView){
            super(itemView);
            tv_paymentName = itemView.findViewById(R.id.tv_paymentName);
            tv_paymentQuantity = itemView.findViewById(R.id.tv_paymentQuantity);
            tv_paymentPrice = itemView.findViewById(R.id.tv_paymentPrice);

        }
    }

    public PaymentAdpater(ArrayList<Order> orderList){
        mOrders = orderList;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cashier_payment_item, parent, false);
        PaymentViewHolder mvh = new PaymentViewHolder(v);

        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        Order currentItem = mOrders.get(position);

        holder.tv_paymentName.setText(currentItem.getName());
        holder.tv_paymentQuantity.setText(currentItem.getQuantity());
        holder.tv_paymentPrice.setText(String.format("%.2f", Double.parseDouble(currentItem.getPrice())));
    }

    @Override
    public int getItemCount() {
        return mOrders.size();
    }
}
