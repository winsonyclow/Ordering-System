package com.example.orderingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class CashierMain extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    private LoginDetail loginDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cashier_main);

        Intent i = getIntent();
        loginDetail = (LoginDetail) i.getSerializableExtra("Login Detail");

        Toolbar toolbar = findViewById(R.id.cashierToolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.cashier_drawer_layout);
        NavigationView navigationView = findViewById(R.id.cashier_nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header = navigationView.getHeaderView(0);

        TextView tv_nav_name = header.findViewById(R.id.nav_header_name);
        tv_nav_name.setText(loginDetail.getName());

        TextView tv_nav_email = header.findViewById(R.id.nav_header_email);
        tv_nav_email.setText(loginDetail.getEmail());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if(savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.cashier_fragment_container, new CashierFragmentHome()).commit();
            navigationView.setCheckedItem(R.id.cashier_nav_home);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.cashier_nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.cashier_fragment_container, new CashierFragmentHome()).commit();
                break;
            case R.id.cashier_nav_payment:
                CashierFagmentPayment mfp = new CashierFagmentPayment();
                Bundle b = new Bundle();
                b.putString("Restaurant ID", loginDetail.getRestaurantId());
                mfp.setArguments(b);
                getSupportFragmentManager().beginTransaction().replace(R.id.cashier_fragment_container, mfp).commit();
                break;
            case R.id.cashier_nav_logout:
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(CashierMain.this, Login.class));
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }
}
