package com.example.orderingsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {
    EditText et_email, et_name, et_password, et_cPassword;
    Button btn_register;
    FirebaseAuth mFirebaseAuth;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    TextView tv_login;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        mFirebaseAuth= FirebaseAuth.getInstance();
        et_email = findViewById(R.id.et_registerEmail);
        et_password = findViewById(R.id.et_registerPassword);
        et_name = findViewById(R.id.et_RegisterName);
        et_cPassword = findViewById(R.id.et_registerCPassword);
        btn_register = findViewById(R.id.btn_register);
        tv_login = findViewById(R.id.tv_login);

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = et_email.getText().toString();
                String password = et_password.getText().toString();
                String cPassword = et_cPassword.getText().toString();
                final String name = et_name.getText().toString();

                if(email.isEmpty() && password.isEmpty()){
                    Toast.makeText(Register.this, "Fields are empty!",Toast.LENGTH_SHORT).show();
                }
                else if(email.isEmpty()){
                    et_email.setError("Please enter email");
                    et_email.requestFocus();
                }
                else if(name.isEmpty()){
                    et_name.setError("Please enter name");
                    et_name.requestFocus();
                }
                else if(password.isEmpty()){
                    et_password.setError("Please enter password");
                    et_password.requestFocus();
                }
                else if(cPassword.isEmpty()){
                    et_cPassword.setError("Please enter confirm password");
                    et_cPassword.requestFocus();
                }
                else if(!password.equals(cPassword)){
                    et_password.setError("");
                    et_cPassword.setError("Password are not the same");
                    et_cPassword.requestFocus();
                }
                else if(!(email.isEmpty() && name.isEmpty() && password.isEmpty() && cPassword.isEmpty())){
                    mFirebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(Register.this, "Register Fail",Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(Register.this, "Register Successfully",Toast.LENGTH_SHORT).show();

                                rootNode = FirebaseDatabase.getInstance();
                                reference = rootNode.getReference("user");
                                FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser() ;
                                final String uid = currentFirebaseUser.getUid();
                                String email = currentFirebaseUser.getEmail();
                                LoginDetail ld = new LoginDetail(email, name, uid, "member", "1");
                                reference.child(uid).setValue(ld);

                                final LoginDetail[] d = new LoginDetail[1];
                                final FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference ref = database.getReference("user");
                                ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        for(DataSnapshot ds : dataSnapshot.getChildren()){
                                            if(ds.child("uid").getValue().toString().equals(uid)){
                                                d[0] = new LoginDetail(ds.child("email").getValue().toString(), ds.child("name").getValue().toString(),
                                                        ds.child("uid").getValue().toString(), ds.child("status").getValue().toString(), ds.child("restaurantId").getValue().toString());
                                            }
                                        }
                                        LoginDetail ld = d[0];
                                        Intent i = new Intent(Register.this, MemberMain.class);
                                        i.putExtra("Login Detail", ld);
                                        finish();
                                        startActivity(i);
                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {
                                        System.out.println("The read failed: " + databaseError.getCode());
                                    }
                                });
                            }
                        }
                    });
                }
                else{
                    Toast.makeText(Register.this, "Error Occurred!",Toast.LENGTH_SHORT).show();
                }
            }
        });

        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(Register.this, Login.class));
            }
        });
    }
}
