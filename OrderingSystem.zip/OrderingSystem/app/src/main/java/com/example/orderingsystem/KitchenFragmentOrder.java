package com.example.orderingsystem;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class KitchenFragmentOrder extends Fragment{
    private RecyclerView mRecyclerView;
    private OrderAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private String orderId;
    DatabaseReference mDatabaseReference;
    private ArrayList<Order> orders = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.kitchen_fragment_order, container, false);

        Bundle b = getArguments();
        final String restaurantId = b.getString("Restaurant ID");

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("order");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    if(orders.size()>0){
                        boolean contain = false;
                        for(Order o : orders) {
                            if(o.getOrderId().equals(ds.child("orderId").getValue().toString())) {
                                contain = true;
                            }
                        }
                        if(!contain){
                            if(ds.child("restaurantId").getValue().toString().equals(restaurantId)
                                    && ds.child("progress").getValue().toString().equals("1")){
                                orders.add(new Order(ds.child("name").getValue().toString(), ds.child("tableNo").getValue().toString(),
                                        ds.child("quantity").getValue().toString(), ds.child("orderId").getValue().toString()));
                            }
                        }
                    }
                    else{
                        if(ds.child("restaurantId").getValue().toString().equals(restaurantId)
                                && ds.child("progress").getValue().toString().equals("1")){
                            orders.add(new Order(ds.child("name").getValue().toString(), ds.child("tableNo").getValue().toString(),
                                    ds.child("quantity").getValue().toString(), ds.child("orderId").getValue().toString()));
                        }
                    }
                }

                mRecyclerView = view.findViewById(R.id.rv_kitchenOrder);
                mRecyclerView.setHasFixedSize(true);
                mLayoutManager = new LinearLayoutManager(getContext());
                mAdapter = new OrderAdapter(orders);

                mRecyclerView.setLayoutManager(mLayoutManager);
                mRecyclerView.setAdapter(mAdapter);



                mAdapter.setOnItemClickListener(new OrderAdapter.OnItemClickListener() {
                    @Override
                    public void OnCompleteClick(int position) {
                        orderId = orders.get(position).getOrderId();
                        openDialog(orderId, position);
                    }
                });

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });

        return view;
    }

    public void openDialog(final String orderId, final int position){
        AlertDialog.Builder ad = new AlertDialog.Builder(getActivity());
        ad.setTitle("Complete Order");
        ad.setMessage("Are you sure?");
        ad.setPositiveButton("Complete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mDatabaseReference = FirebaseDatabase.getInstance().getReference("order");
                mDatabaseReference.child(orderId).child("progress").setValue("2");
                orders.remove(position);
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        ad.show();
    }
}
