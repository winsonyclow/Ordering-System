package com.example.orderingsystem;
import java.io.Serializable;

public class RestaurantSeat implements Serializable {
    public String restaurantId;
    public String seatNo;

    public RestaurantSeat() {

    }

    public RestaurantSeat(String restaurantId, String seatNo){
        this.restaurantId = restaurantId;
        this.seatNo = seatNo;
    }

    public String getRestaurantId() {
        return restaurantId;
    }

    public String getSeatNo() {
        return seatNo;
    }
}
