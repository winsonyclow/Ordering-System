package com.example.orderingsystem;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CashierPayment extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private PaymentAdpater mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    DatabaseReference mDatabaseReference;
    private ArrayList<Order> orders = new ArrayList<>();
    private TextView tv_paymentTotalPrice;
    private double totalPrice;
    private String uid, restaurantId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cashier_payment);

        tv_paymentTotalPrice = findViewById(R.id.tv_paymentTotalPrice);

        Intent i = getIntent();
        uid = i.getExtras().getString("uid");
        restaurantId = i.getExtras().getString("Restaurant ID");

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("order");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    if(orders.size()>0){
                        boolean contain = false;
                        for(Order o : orders) {
                            if(o.getOrderId().equals(ds.child("orderId").getValue().toString())) {
                                contain = true;
                            }
                        }
                        if(!contain){
                            if(ds.child("uid").getValue().toString().equals(uid)
                                    && ds.child("progress").getValue().toString().equals("2")
                                    && ds.child("restaurantId").getValue().toString().equals(restaurantId)){
                                orders.add(new Order(ds.child("name").getValue().toString(), ds.child("quantity").getValue().toString(),
                                        ds.child("price").getValue().toString(), ds.child("orderId").getValue().toString(), uid));

                                totalPrice += Double.parseDouble(ds.child("price").getValue().toString());
                            }
                        }
                    }
                    else{
                        if(ds.child("uid").getValue().toString().equals(uid)
                                && ds.child("progress").getValue().toString().equals("2")
                                && ds.child("restaurantId").getValue().toString().equals(restaurantId)){
                            orders.add(new Order(ds.child("name").getValue().toString(), ds.child("quantity").getValue().toString(),
                                    ds.child("price").getValue().toString(), ds.child("orderId").getValue().toString(), uid));

                            totalPrice += Double.parseDouble(ds.child("price").getValue().toString());
                        }
                    }
                }

                if(orders.size() > 0){
                    mRecyclerView = findViewById(R.id.rv_cashierPayment);
                    mRecyclerView.setHasFixedSize(true);
                    mLayoutManager = new LinearLayoutManager(getBaseContext());
                    mAdapter = new PaymentAdpater(orders);

                    tv_paymentTotalPrice.setText(String.format("%.2f", totalPrice));

                    mRecyclerView.setLayoutManager(mLayoutManager);
                    mRecyclerView.setAdapter(mAdapter);
                }
                else{
                    Toast.makeText(CashierPayment.this, "Payment has been made", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }


    public void CompletePayment(View view) {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setTitle("Complete Payment");
        ad.setMessage("Are you sure to complete the payment?");
        ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                for(Order o : orders){
                    mDatabaseReference = FirebaseDatabase.getInstance().getReference("order");
                    mDatabaseReference.child(o.getOrderId()).child("progress").setValue("3");
                }
                Toast.makeText(CashierPayment.this, "Payment has been completed", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        ad.show();
    }
}
