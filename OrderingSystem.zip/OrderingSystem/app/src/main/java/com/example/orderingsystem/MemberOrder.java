package com.example.orderingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class MemberOrder extends AppCompatActivity {

    TextView tv_name, tv_price, tv_quantity;
    ImageView iv_food;
    int count = 1;
    double price;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_order);

        tv_name = findViewById(R.id.tv_name);
        tv_price = findViewById(R.id.tv_price);
        tv_quantity = findViewById(R.id.tv_quantity);
        iv_food = findViewById(R.id.iv_food);

        order = (Order) getIntent().getSerializableExtra("Order");

        iv_food.setImageResource(order.getImageResource());
        tv_name.setText(order.getName());
        tv_price.setText(String.format("%.2f", Double.parseDouble(order.getPrice())));

        price = Double.parseDouble(tv_price.getText().toString());
    }

    public void IncreaseQuantity(View v){
        if(count == 10){
            Toast.makeText(MemberOrder.this, "Maximum quantity exceeded", Toast.LENGTH_SHORT).show();
        }
        else{
            count++;
            tv_quantity.setText(Integer.toString(count));
            double total = price * count;
            tv_price.setText(String.format("%.2f", total));
        }
    }

    public void DecreaseQuantity(View v){
        if(count == 1){
            Toast.makeText(MemberOrder.this, "Minimum quantity exceeded", Toast.LENGTH_SHORT).show();
        }
        else{
            count--;
            tv_quantity.setText(Integer.toString(count));
            double total = price * count;
            tv_price.setText(String.format("%.2f", total));
        }
    }

    public void CompleteOrder(View view) {
        UUID uuid = UUID.randomUUID();

        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("order");

        Order o = new Order(order.getRestaurantId(), order.getMenuId(), order.getUid(),
                order.getTableNo(), tv_price.getText().toString(), tv_name.getText().toString(),
                tv_quantity.getText().toString(), "1", uuid.toString());
        reference.child(uuid.toString()).setValue(o);

        Toast.makeText(MemberOrder.this, "Order has been sent to the kitchen", Toast.LENGTH_SHORT).show();
        finish();
    }

}